#!/bin/bash
LD_PRELOAD=./lib/libsfml-system.so.2.5
LD_PRELOAD=./lib/libsfml-audio.so.2.5
./sound.bin
