#!/bin/bash
##g++ -Wall -std=c++11 -I./include ./lib/libsqlite3.so main.cpp -o ./build/gnu_linux/dbh_example.bin
g++ -Wall -std=c++11 -I./include ./lib/libsfml-system.so.2.5 ./lib/libsfml-audio.so.2.5 Sound.cpp -o ./sound.bin



